package Classes;

import DAO.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author User
 */
public class Paciente{

 private String nome;
    private String email;
    private String usuario;
    private String senha;
    private boolean adm;
    private String login;
    private boolean sexo;
    private int telefone;
    private int cpf;
    private int id;

    public Paciente(){
        
    }
    public Paciente(String login, boolean sexo, int telefone, int cpf, int id) {
        this.login = login;
        this.sexo = sexo;
        this.telefone = telefone;
        this.cpf = cpf;
        this.id = id;
    }
    
    
    public Paciente(String nome, String email, String usuario, String senha, boolean adm) {
        this.nome = nome;
        this.email = email;
        this.usuario = usuario;
        this.senha = senha;
        this.adm = adm;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public boolean isSexo() {
        return sexo;
    }

    public void setSexo(boolean sexo) {
        this.sexo = sexo;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }

    public int getCpf() {
        return cpf;
    }

    public void setCpf(int cpf) {
        this.cpf = cpf;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public boolean isAdm() {
        return adm;
    }

    public void setAdm(boolean adm) {
        this.adm = adm;
    }
public void inserir(){
    
    String sql = "INSERT INTO tb_pessoa(nome, login, email, senha, telefone, cpf, sexo, id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    ConnectionFactory factory = new ConnectionFactory();
    
    try (Connection c = factory.obtemConexao()){
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setString(1, nome);
        ps.setString(2, login);
        ps.setString(3, email);
        ps.setString(4, senha);
        ps.setInt(5, telefone);
        ps.setInt(6,cpf );
        ps.setBoolean(7, sexo);
        ps.setInt(8, id);
        ps.execute();
        
        JOptionPane.showMessageDialog(null, "Usuário Incluído com Sucesso!");
    }
    catch (Exception e){
        e.printStackTrace();
    }
} 

public void alterar(){
    
    String sql = "update tb_pessoa(set nome = ?, set login = ?, set email = ?, set senha = ?, set telefone = ?, set cpf = ?, set sexo = ?, set id = ?)";
    ConnectionFactory factory = new ConnectionFactory();
    
    try (Connection c = factory.obtemConexao()){
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setString(1, nome);
        ps.setString(2, login);
        ps.setString(3, email);
        ps.setString(4, senha);
        ps.setInt(5, telefone);
        ps.setInt(6,cpf );
        ps.setBoolean(7, sexo);
        ps.setInt(8, id);
        ps.execute();
        
        JOptionPane.showMessageDialog(null, "Usuário Incluído com Sucesso!");
    }
    catch (Exception e){
        e.printStackTrace();
    }
}
public void excluir(int id) {
    String sql = "DELETE FROM tb_pessoa WHERE id = ?";
    ConnectionFactory factory = new ConnectionFactory();

    try (Connection c = factory.obtemConexao()) {
        PreparedStatement ps = c.prepareStatement(sql);
        ps.setString(1, nome);
        ps.setString(2, login);
        ps.setString(3, email);
        ps.setString(4, senha);
        ps.setInt(5, telefone);
        ps.setInt(6,cpf );
        ps.setBoolean(7, sexo);
        ps.setInt(8, id);
        ps.execute();

        JOptionPane.showMessageDialog(null, "Usuário Excluído com Sucesso!");
    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(null, "Erro ao excluir usuário!");
    }
}}

