package Classes;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import DAO.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;
import javax.swing.JOptionPane;

public class Agenda {
String pacienteNome;  
String medicoNome;
Date data;
String horario;
String motivo;
int id;

    public String getPacienteNome() {
        return pacienteNome;
    }

    public void setPacienteNome(String pacienteNome) {
        this.pacienteNome = pacienteNome;
    }

    public String getMedicoNome() {
        return medicoNome;
    }

    public void setMedicoNome(String medicoNome) {
        this.medicoNome = medicoNome;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Agenda(String pacienteNome, String medicoNome, Date data, String horario, String motivo, int id) {
        this.pacienteNome = pacienteNome;
        this.medicoNome = medicoNome;
        this.data = data;
        this.horario = horario;
        this.motivo = motivo;
        this.id = id;
    }



   
public void alterar () {
  
 String sql = "update tb_pessoa (set pacienteNome =?, set medicoNome =?, set data =?, set horario =?, set motivo =?, set id =?)";
 
 ConnectionFactory factory = new ConnectionFactory();
 
 try (Connection c = factory.obtemConexao()){
        PreparedStatement ps = c.prepareStatement(sql);
        
  ps.setString(1, pacienteNome);
  ps.setString(2, medicoNome);
  ps.setDate(3, (java.sql.Date) data);
  ps.setString(4, horario);
  ps.setString(5, motivo);
  ps.setInt(6, id);
 ps.executeUpdate();
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Usuário alterado com sucesso!");
    }
}
}
