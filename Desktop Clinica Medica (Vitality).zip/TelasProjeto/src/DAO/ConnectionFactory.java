/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;
// precisa mudar a senha e root e mudar  nome do banco de dados//  
import java.sql.Connection;
import java.sql.DriverManager;
public class ConnectionFactory {
private String usuario = "root";
private String senha = "1234";
private String host = "localhost";
private String porta = "3306";
private String bd = "db_vitality";
public Connection obtemConexao (){
try{
Connection c = DriverManager.getConnection(
"jdbc:mysql://" + host + ":" + porta + "/" + bd+"?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
usuario,
senha
);
System.out.println("Conexao Efetuada");
return c;
}
catch (Exception e){
e.printStackTrace();
System.out.println("ERRO, não conectado!");
return null;
}}} 
